#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// =========================
// OLED
// =========================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define SDA_PIN 21
#define SCL_PIN 22

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

// =========================
// DHT22
// =========================
#define DHT_PIN 4
#define DHT_TYPE DHT22

DHT dht(DHT_PIN, DHT_TYPE);

// =========================
// SOIL SENSOR
// Wokwi potentiometer
// =========================
#define SOIL_PIN 34

// =========================
// OUTPUTS
// =========================
#define WARNING_LED 2
#define RELAY_PIN 26

// Relay module is usually active LOW
#define RELAY_ON LOW
#define RELAY_OFF HIGH

// =========================
// THRESHOLDS
// =========================
#define DRY_LIMIT 30
#define HIGH_TEMP 35.0

// Pump duration
#define PUMP_TIME 3000;

// =========================
// SETUP
// =========================
void setup()
{
  Serial.begin(115200);

  // Pins
  pinMode(SOIL_PIN, INPUT);

  pinMode(WARNING_LED, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);

  digitalWrite(WARNING_LED, LOW);
  digitalWrite(RELAY_PIN, RELAY_OFF);

  // DHT
  dht.begin();

  // OLED
  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(
        SSD1306_SWITCHCAPVCC,
        0x3C))
  {
    Serial.println("OLED ERROR");

    while (true);
  }

  display.clearDisplay();

  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(1);

  display.setCursor(20, 20);
  display.println("SMART PLANT");

  display.setCursor(20, 35);
  display.println("STARTING...");

  display.display();

  delay(2000);
}


// =========================
// READ SOIL
// =========================
int readSoil()
{
  int raw = analogRead(SOIL_PIN);

  /*
     Wokwi potentiometer:
     0    = very wet
     4095 = very dry

     Convert to percentage:
     0    -> 100%
     4095 -> 0%
  */

  int moisture = map(
    raw,
    0,
    4095,
    100,
    0
  );

  moisture = constrain(
    moisture,
    0,
    100
  );

  return moisture;
}


// =========================
// OLED DISPLAY
// =========================
void showData(
  float temp,
  float humidity,
  int soil,
  String status
)
{
  display.clearDisplay();

  display.setTextColor(
    SSD1306_WHITE
  );

  display.setTextSize(1);

  display.setCursor(0, 0);
  display.println("SMART PLANT");

  display.drawLine(
    0,
    10,
    127,
    10,
    SSD1306_WHITE
  );

  display.setCursor(0, 15);
  display.print("TEMP : ");
  display.print(temp, 1);
  display.println(" C");

  display.setCursor(0, 27);
  display.print("AIR  : ");
  display.print(humidity, 0);
  display.println(" %");

  display.setCursor(0, 39);
  display.print("SOIL : ");
  display.print(soil);
  display.println(" %");

  display.setCursor(0, 52);
  display.print(status);

  display.display();
}


// =========================
// MAIN LOOP
// =========================
void loop()
{
  // Read DHT
  float temperature =
    dht.readTemperature();

  float humidity =
    dht.readHumidity();

  // Check DHT
  if (
    isnan(temperature) ||
    isnan(humidity)
  )
  {
    display.clearDisplay();

    display.setTextColor(
      SSD1306_WHITE
    );

    display.setTextSize(1);

    display.setCursor(20, 25);
    display.println("DHT ERROR");

    display.display();

    delay(2000);

    return;
  }

  // Read soil
  int soil = readSoil();

  // Conditions
  bool soilDry =
    soil < DRY_LIMIT;

  bool temperatureHigh =
    temperature > HIGH_TEMP;

  String status;


  // ====================================
  // CONDITION 1:
  // HIGH TEMP + DRY SOIL
  // ====================================
  if (
    soilDry &&
    temperatureHigh
  )
  {
    status = "PLANT STRESS";

    digitalWrite(
      WARNING_LED,
      HIGH
    );

    showData(
      temperature,
      humidity,
      soil,
      status
    );

    // Pump ON
    digitalWrite(
      RELAY_PIN,
      RELAY_ON
    );

    Serial.println(
      "PLANT STRESS - WATERING"
    );

    delay(3000);

    // Pump OFF
    digitalWrite(
      RELAY_PIN,
      RELAY_OFF
    );
  }


  // ====================================
  // CONDITION 2:
  // SOIL DRY
  // ====================================
  else if (soilDry)
  {
    status = "LOW WATER";

    digitalWrite(
      WARNING_LED,
      HIGH
    );

    showData(
      temperature,
      humidity,
      soil,
      status
    );

    // Pump ON
    digitalWrite(
      RELAY_PIN,
      RELAY_ON
    );

    Serial.println(
      "LOW WATER - PUMP ON"
    );

    delay(3000);

    // Pump OFF
    digitalWrite(
      RELAY_PIN,
      RELAY_OFF
    );
  }


  // ====================================
  // CONDITION 3:
  // HIGH TEMPERATURE
  // ====================================
  else if (temperatureHigh)
  {
    status = "HIGH TEMP";

    digitalWrite(
      WARNING_LED,
      HIGH
    );

    digitalWrite(
      RELAY_PIN,
      RELAY_OFF
    );

    showData(
      temperature,
      humidity,
      soil,
      status
    );

    Serial.println(
      "HIGH TEMPERATURE"
    );
  }


  // ====================================
  // CONDITION 4:
  // NORMAL
  // ====================================
  else
  {
    status = "PLANT OK";

    digitalWrite(
      WARNING_LED,
      LOW
    );

    digitalWrite(
      RELAY_PIN,
      RELAY_OFF
    );

    showData(
      temperature,
      humidity,
      soil,
      status
    );

    Serial.println(
      "PLANT OK"
    );
  }


  // Serial Monitor
  Serial.println("--------------------");

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  Serial.print("Soil: ");
  Serial.print(soil);
  Serial.println(" %");

  Serial.println();
  
  delay(2000);
}